import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import http from "http";
import { Server } from "socket.io";

import authRoutes from "./routes/authRoutes.js";
import orderRoutes from "./routes/orderRoutes.js";
import priceRoutes from "./routes/priceRoutes.js";
import matchRoutes from "./routes/matchRoutes.js";

import { startPriceSimulation } from "./utils/priceSimulator.js";

const app = express();
const server = http.createServer(app);

// SOCKET SERVER
const io = new Server(server, {
  cors: { origin: "*" }
});

app.use(express.json());
app.use(cors());

// CONNECT MONGO
mongoose.connect("mongodb://127.0.0.1:27017/stockprox")
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

// ROUTES
app.use("/api/auth", authRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/orders/match", matchRoutes);
app.use("/api/prices", priceRoutes);

// SOCKET CONNECTION
io.on("connection", (socket) => {
  console.log("Client connected:", socket.id);
});

// START LIVE PRICE ENGINE
startPriceSimulation(io);

// START SERVER
server.listen(5000, () => {
  console.log("API running on port 5000");
});