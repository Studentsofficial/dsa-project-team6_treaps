export let STOCK_PRICES = {
  "RELIANCE": 2400,
  "TCS": 3500,
  "INFY": 1500,
  "HDFC": 1600,
  "ICICI": 900,
  "SBI": 600,
  "HCL": 1200,
  "WIPRO": 500,
  "BHARTI": 850,
  "ADANI": 1800,
  "NTPC": 220,
  "ONGC": 180,
  "MARUTI": 9000,
  "TITAN": 3000,
  "ULTRA": 8000,
  "BAJAJ": 7000,
  "HUL": 2600,
  "ITC": 450,
  "LT": 2800,
  "AXIS": 950
};

export function startPriceSimulation(io) {
  setInterval(() => {
    Object.keys(STOCK_PRICES).forEach(stock => {
      let change = (Math.random() - 0.5) * 10;
      STOCK_PRICES[stock] += change;
    });
    io.emit("priceUpdate", STOCK_PRICES);
  }, 1500);
}