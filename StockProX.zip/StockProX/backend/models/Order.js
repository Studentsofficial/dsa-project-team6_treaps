import mongoose from "mongoose";

const orderSchema = new mongoose.Schema({
  user: String,
  stock: String,
  price: Number,
  qty: Number,
  side: String, // "buy" or "sell"
  timestamp: { type: Date, default: Date.now }
});

export default mongoose.model("Order", orderSchema);