import mongoose from "mongoose";

const tradeSchema = new mongoose.Schema({
  stock: String,
  price: Number,
  qty: Number,
  timestamp: { type: Date, default: Date.now }
});

export default mongoose.model("Trade", tradeSchema);