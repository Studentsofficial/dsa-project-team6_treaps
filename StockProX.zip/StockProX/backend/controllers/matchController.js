import Order from "../models/Order.js";

export const matchOrders = async (req, res) => {
  try {
    const stock = req.params.stock.toUpperCase();

    const buyOrders = await Order.find({ stock, side: "buy" }).sort({ price: -1 });
    const sellOrders = await Order.find({ stock, side: "sell" }).sort({ price: 1 });

    let trades = [];
    let i = 0, j = 0;

    while (i < buyOrders.length && j < sellOrders.length) {
      const buy = buyOrders[i];
      const sell = sellOrders[j];

      if (buy.price >= sell.price) {
        const qty = Math.min(buy.qty, sell.qty);

        trades.push({
          stock,
          price: sell.price,
          qty,
          buyOrderId: buy._id,
          sellOrderId: sell._id
        });

        buy.qty -= qty;
        sell.qty -= qty;

        if (buy.qty === 0) {
          await Order.findByIdAndDelete(buy._id);
          i++;
        } else {
          await buy.save();
        }

        if (sell.qty === 0) {
          await Order.findByIdAndDelete(sell._id);
          j++;
        } else {
          await sell.save();
        }
      } else {
        break;
      }
    }

    res.json({ trades });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};