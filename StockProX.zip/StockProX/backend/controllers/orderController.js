import Order from "../models/Order.js";

// PLACE ORDER (unchanged)
export const placeOrder = async (req, res) => {
  try {
    const { user, stock, price, qty, side } = req.body;

    if (!stock || !price || !qty || !side) {
      return res.status(400).json({ error: "Missing fields" });
    }

    if (price <= 0 || qty <= 0) {
      return res.status(400).json({ error: "Price and quantity must be positive" });
    }

    const order = new Order({
      user,
      stock: stock.toUpperCase(),
      price,
      qty,
      side
    });

    await order.save();
    res.json({ success: true, order });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET ORDER BOOK
export const getOrderBook = async (req, res) => {
  try {
    const stock = req.params.stock.toUpperCase();

    const buyOrders = await Order.find({ stock, side: "buy" }).sort({ price: -1 });
    const sellOrders = await Order.find({ stock, side: "sell" }).sort({ price: 1 });

    res.json({
      buy: buyOrders.map(o => ({ price: o.price, qty: o.qty })),
      sell: sellOrders.map(o => ({ price: o.price, qty: o.qty }))
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE ALL ORDERS
export const clearAllOrders = async (req, res) => {
  try {
    await Order.deleteMany({});
    res.json({ message: "All orders deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE ORDERS FOR ONE STOCK
export const clearStockOrders = async (req, res) => {
  try {
    const stock = req.params.stock.toUpperCase();
    await Order.deleteMany({ stock });
    res.json({ message: `Orders for ${stock} deleted` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getAllOrderBooks = async (req, res) => {
  try {
    const orders = await Order.find().sort({ stock: 1 });

    const result = {};

    orders.forEach(o => {
      if (!result[o.stock]) {
        result[o.stock] = { buy: [], sell: [] };
      }
      result[o.stock][o.side].push({
        price: o.price,
        qty: o.qty
      });
    });

    res.json(result);

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};