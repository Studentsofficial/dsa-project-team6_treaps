import { STOCK_PRICES } from "../utils/priceSimulator.js";

export function getPrices(req, res) {
  res.json(STOCK_PRICES);
}