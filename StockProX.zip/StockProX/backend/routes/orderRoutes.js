import express from "express";
import {
  placeOrder,
  getOrderBook,
  clearAllOrders,
  clearStockOrders,
  getAllOrderBooks
} from "../controllers/orderController.js";

const router = express.Router();

router.post("/place", placeOrder);
router.get("/book/:stock", getOrderBook);
router.get("/book-all", getAllOrderBooks);

router.delete("/clear", clearAllOrders);
router.delete("/clear/:stock", clearStockOrders);

export default router;