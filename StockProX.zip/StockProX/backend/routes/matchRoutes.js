import express from "express";
import { matchOrders } from "../controllers/matchController.js";

const router = express.Router();

// MATCH ROUTE
// GET /api/orders/match/:stock
router.get("/:stock", matchOrders);

export default router;