const API = "http://localhost:5000";
const socket = io(API);

// 20 Stocks
const STOCKS = [
  "RELIANCE","TCS","INFY","HDFC","ICICI","SBI","HCL","WIPRO","BHARTI","ADANI",
  "NTPC","ONGC","MARUTI","TITAN","ULTRA","BAJAJ","HUL","ITC","LT","AXIS"
];

// Populate dropdown
const stockSelect = document.getElementById("stockSelect");
STOCKS.forEach(s => {
  const opt = document.createElement("option");
  opt.value = s;
  opt.textContent = s;
  stockSelect.appendChild(opt);
});

// LIVE PRICE UPDATES
socket.on("priceUpdate", prices => {
  const grid = document.getElementById("prices");
  grid.innerHTML = "";

  Object.entries(prices).forEach(([name, price]) => {
    grid.innerHTML += `
      <div class="stock-card">
         <strong>${name}</strong><br>₹ ${price.toFixed(2)}
      </div>`;
  });
});

// PLACE ORDER
async function placeOrder(side) {
  let stock = stockSelect.value;
  let price = Number(document.getElementById("priceInput").value);
  let qty = Number(document.getElementById("qtyInput").value);

  // VALIDATION
  if (!stock || price <= 0 || qty <= 0) {
    alert("⚠️ Invalid order. Enter positive price & quantity.");
    return;
  }

  const res = await fetch(`${API}/api/orders/place`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user: "demoUser", stock, price, qty, side })
  });

  const data = await res.json();

  if (!data.success && data.message) {
    alert("⚠️ " + data.message);
    return;
  }

  alert("Order placed!");
  loadOrderbook();
}

async function loadOrderbook() {
  const res = await fetch(`${API}/api/orders/book-all`);
  const data = await res.json();

  const ob = document.getElementById("orderbook");
  ob.innerHTML = "";

  for (let stock in data) {
    ob.innerHTML += `<h3 style="color:#00eaff">${stock}</h3>`;
    ob.innerHTML += "<strong>BUY</strong><br>";

    if (data[stock].buy.length === 0)
      ob.innerHTML += `<div>No Buy Orders</div>`;
    else
      data[stock].buy.forEach(b => {
        ob.innerHTML += `<div>${stock} → ₹${b.price} | Qty: ${b.qty}</div>`;
      });

    ob.innerHTML += "<strong>SELL</strong><br>";

    if (data[stock].sell.length === 0)
      ob.innerHTML += `<div>No Sell Orders</div>`;
    else
      data[stock].sell.forEach(s => {
        ob.innerHTML += `<div>${stock} → ₹${s.price} | Qty: ${s.qty}</div>`;
      });

    ob.innerHTML += "<hr style='border:1px solid #333'>";
  }
}

// MATCH ORDERS
async function matchOrders() {
  const stock = stockSelect.value;

  const res = await fetch(`${API}/api/orders/match/${stock}`);
  const data = await res.json();

  const t = document.getElementById("trades");
  t.innerHTML = "";

  if (data.trades.length === 0) {
    t.innerHTML = "<div>No trades executed</div>";
  }

  data.trades.forEach(tr => {
    t.innerHTML += `<div>Matched ₹ ${tr.price} | Qty ${tr.qty}</div>`;
  });

  loadOrderbook();
}

// RESET ONE STOCK
async function resetStock() {
  const stock = stockSelect.value;

  if (!confirm(`⚠️ Delete ALL orders for ${stock}?`)) return;

  await fetch(`${API}/api/orders/clear/${stock}`, { method: "DELETE" });

  alert(`${stock} orders cleared.`);
  loadOrderbook();
}

// RESET ALL STOCKS
async function resetAll() {
  if (!confirm("⚠️ Delete ALL orders for ALL stocks?")) return;

  await fetch(`${API}/api/orders/clear`, { method: "DELETE" });

  alert("All orders cleared.");
  loadOrderbook();
}

// Refresh orderbook every 2 seconds
setInterval(() => loadOrderbook(), 2000);