// ----- 20 Top Indian Stocks -----
const stocks = {
    "RELIANCE": 2450,
    "TCS": 3470,
    "INFY": 1550,
    "WIPRO": 420,
    "HCLTECH": 1280,
    "ITC": 450,
    "ASIANPAINT": 2990,
    "HDFC": 1620,
    "ICICI": 1030,
    "SBIN": 610,
    "KOTAKBANK": 1750,
    "MARUTI": 9960,
    "TITAN": 3450,
    "ULTRA": 9100,
    "ONGC": 180,
    "BHARTIARTL": 960,
    "JSWSTEEL": 830,
    "TATAMOTORS": 710,
    "ADANIENT": 2550,
    "BAJAJFINSV": 1570
};

// ----- Render Cards -----
const board = document.getElementById("priceBoard");

function renderPrices() {
    board.innerHTML = "";

    for (let s in stocks) {
        let div = document.createElement("div");
        div.className = "card";
        div.innerHTML = `
            <div>${s}</div>
            <div id="price-${s}" class="price">₹${stocks[s]}</div>
        `;
        board.appendChild(div);
    }
}

renderPrices();

// ----- Update Prices Every 2 Seconds -----
setInterval(() => {
    for (let s in stocks) {
        let change = Math.floor(Math.random() * 40 - 20); // -20 to +20
        let old = stocks[s];
        stocks[s] = Math.max(1, old + change);

        let priceDiv = document.getElementById(`price-${s}`);
        priceDiv.innerText = "₹" + stocks[s];
        priceDiv.className = "price " + (change >= 0 ? "up" : "down");
    }
}, 2000);