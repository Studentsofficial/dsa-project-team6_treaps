async function login() {
    const user = document.getElementById("user").value;
    const pass = document.getElementById("pass").value;

    let res = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: user, password: pass })
    });

    let data = await res.json();

    if (data.success) {
        localStorage.setItem("token", data.token);
        window.location.href = "index.html";
    } else {
        document.getElementById("msg").innerText = data.message;
    }
}